# 🛒 Product Category Classifier

Automatska klasifikacija proizvoda po kategorijama na osnovu **naslova proizvoda**.  
Projekat razvijen kao deo zadatka za razvoj ML modela koji olakšava unos i kategorizaciju proizvoda na e-commerce platformi.

---

## 🎯 Cilj zadatka

Razviti model koji na osnovu `Product Title` automatski predlaže odgovarajuću `Category Label`.  
Model treba da zameni ručno razvrstavanje proizvoda i tako ubrza rad tima i smanji broj grešaka.

---

## 📦 Dataset

Skup podataka: **products.csv**  
Sadrži više od 30.000 zapisa sa sledećim kolonama:
- Product ID  
- Product Title  
- Merchant ID  
- Category Label  
- Product Code  
- Number of Views  
- Merchant Rating  
- Listing Date

Za model su najvažnije kolone:
- **Product Title** – ulazni tekst (naziv proizvoda)  
- **Category Label** – ciljna varijabla (kategorija proizvoda)

---

## ⚙️ Tehnologije i pristup

Model koristi kombinaciju:

- **TF-IDF vektorizacije teksta** (pretvara naslove proizvoda u numeričke reprezentacije)  
- **Logistic Regression klasifikatora** (učeni model za predviđanje kategorije)

Pipeline je realizovan u **scikit-learn** biblioteci.

---

## 🧠 Rezultati evaluacije

Model je treniran na 80% podataka, a testiran na 20%.  
**Test tačnost (accuracy):** ≈ 95.28%  

Broj kategorija: 13  
Broj primera za treniranje: 28076  
Broj primera za test: 7020

---

## 🔍 Test primeri predikcija

| Proizvod | Očekivana kategorija | Predikcija modela |
|-----------|----------------------|--------------------|
| iphone 7 32gb gold,4,3,Apple iPhone 7 32GB | Mobile Phones | ✅ **Mobile Phones** |
| olympus e m10 mark iii geh use silber | Digital Cameras | ✅ **Digital Cameras** |
| kenwood k20mss15 solo | Microwaves | ✅ **Microwaves** |
| bosch wap28390gb 8kg 1400 spin | Washing Machines | ✅ **Washing Machines** |
| bosch serie 4 kgv39vl31g | Fridge Freezers | ⚠️ *Dishwashers* |
| smeg sbs8004po | Fridge Freezers | ⚠️ *Fridges* |

---

## 🧩 Struktura projekta

```
product_classifier_project/
│
├── model.pkl                         # trenirani model (TF-IDF + LogisticRegression)
├── train_model.py                     # skript za treniranje i čuvanje modela
├── predict_category.py                # interaktivni skript za testiranje
├── product_classification_notebook.ipynb  # Jupyter notebook sa analizom
├── metadata.json                      # osnovne metrike i info o modelu
├── products.csv                       # skup podataka
├── requirements.txt                   # zavisnosti
└── README.md                          # ovaj fajl
```

---

## ▶️ Pokretanje projekta

### 1. Instalacija zavisnosti
```bash
pip install -r requirements.txt
```

### 2. Pokretanje interaktivnog prediktora
```bash
python predict_category.py --model model.pkl
```
Zatim unesite naziv proizvoda (prazan unos izlazi iz programa).

### 3. Ponovno treniranje modela
```bash
python train_model.py --data products.csv --out model.pkl
```

---

## 📈 Dalji koraci i moguće nadogradnje

- Dodavanje feature engineering-a (brend, dužina naslova, broj cifara, velika slova itd.)  
- Uvođenje naprednijih modela (XGBoost, Transformer-based modeli poput BERT-a)  
- Balansiranje klasa i analiza grešaka pomoću matrice zabune  
- Izgradnja REST API servisa (FastAPI/Flask) za integraciju sa e-commerce platformom  

---

## 👤 Autor

Ovaj projekat je kreiran kao deo zadatka za **automatizovanu kategorizaciju proizvoda**.  
Struktura i dokumentacija su pripremljeni u skladu sa standardima timskog rada i GitHub organizacije.
